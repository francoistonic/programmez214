// ereg_replace ne fonctionne plus sur PHP 7
$FAN=strtoupper(ereg_replace('[^[:alnum:]\\?]', '', $VAT));
// On la remplace par un preg_replace avec des délimiteurs.
// ici ce sera des slashes /
$FAN=strtoupper(preg_replace("/[^[:alnum:]\?]/","",$VAT));


// ereg ne fonctionne plus sur PHP 7
$OK= ereg('(^[0-9]{1,8})([0-9]{2}$|\\?{1,2}$)', $FAN, $REGS);
// On la remplace par un preg_match avec des délimiteurs.
// ici ce sera des slashes /
$OK=preg_match("/(^[0-9]{1,8})([0-9]{2}$|\?{1,2}$)/",$FAN,$REGS);

// Imaginons que la fonction était eregi
// Alors on aurait seulement à rajouter un i ce qui donnerait
$OK=preg_match("/(^[0-9]{1,8})([0-9]{2}$|\?{1,2}$)/i",$FAN,$REGS);
