File: /app/orditech.application/third_party/PDFMerger/fpdi/pdf_parser.php
> Line 94: PHP 4 constructors are now deprecated
    function pdf_parser($filename)
    {
    }
> Line 104: Result of new is assigned by reference
    $this->c =& new \pdf_context($this->f);
> Line 217: Result of new is assigned by reference
    $c =& new \pdf_context($this->f);

File: /app/orditech.application/third_party/PDFMerger/fpdi/fpdf_tpl.php
> Line 172: Possible array element creation during by-reference assignment
    $this->_res['tpl'][$this->tpl]['tpls'][$tplidx] =& $this->tpls[$tplidx];
> Line 260: Possible array element creation during by-reference assignment
    $this->_res['tpl'][$this->tpl]['fonts'][$fontkey] =& $this->fonts[$fontkey];

File: /app/orditech.application/third_party/PDFMerger/fpdi/fpdi_pdf_parser.php
> Line 69: PHP 4 constructors are now deprecated
    function fpdi_pdf_parser($filename, &$fpdi)
    {
    }
> Line 239: Result of new is assigned by reference
    $decoder =& new \FilterLZW_FPDI($this->fpdi);
> Line 244: Result of new is assigned by reference
    $decoder =& new \FilterASCII85_FPDI($this->fpdi);

File: /app/orditech.application/third_party/PDFMerger/fpdf/tutorial/tuto6.php
> Line 11: PHP 4 constructors are now deprecated
    function PDF($orientation = 'P', $unit = 'mm', $format = 'A4')
    {
    }

File: /app/orditech.application/third_party/PDFMerger/fpdf/font/makefont/makefont.php
> Line 304: Removed function "set_magic_quotes_runtime" called
    set_magic_quotes_runtime(0);

File: /app/orditech.application/third_party/PDFMerger/fpdf/fpdf.php
> Line 75: PHP 4 constructors are now deprecated
    function FPDF($orientation = 'P', $unit = 'mm', $format = 'A4')
    {
    }
> Line 1074: Removed function "set_magic_quotes_runtime" called
    set_magic_quotes_runtime(0);

File: /app/orditech.application/third_party/FPDI/fpdf_tpl.php
> Line 144: Possible array element creation during by-reference assignment
    $this->_res['tpl'][$this->tpl]['fonts'][$fontKey] =& $this->fonts[$fontKey];
> Line 162: Function argument(s) returned by "func_get_args" might have been modified
    func_get_args();
> Line 366: Function argument(s) returned by "func_get_args" might have been modified
    func_get_args();

File: /app/orditech.application/third_party/Numbers_Words/Numbers/Words/Locale/bg.php
> Line 272: PHP 4 constructors are now deprecated
    function Numbers_Words_Locale_bg()
    {
    }
> Line 293: Possible array element creation during by-reference assignment
    $this->_digits[1][$i] =& $this->_digits[0][$i];
> Line 296: Possible array element creation during by-reference assignment
    $this->_digits[-1][$i] =& $this->_digits[0][$i];

File: /app/orditech.application/third_party/dompdf/dompdf.php
> Line 185: Removed function "split" called
    split(',', $opts['t']);


File: /app/orditech.application/third_party/dompdf/include/page_frame_reflower.cls.php
> Line 178: Indirect variable, property or method access
    $f[0]->{$f[1]}($info);

File: /app/orditech.application/third_party/dompdf/include/frame.cls.php
> Line 190: Possible array element creation during by-reference assignment
    $this->_containing_block[0] =& $this->_containing_block['x'];
> Line 191: Possible array element creation during by-reference assignment
    $this->_containing_block[1] =& $this->_containing_block['y'];

File: /app/orditech.application/third_party/dompdf/include/renderer.cls.php
> Line 226: Indirect variable, property or method access
    $f[0]->{$f[1]}($info);

File: /app/orditech.application/helpers/MY_url_helper.php
> Line 61: Function argument(s) returned by "func_get_args" might have been modified
    func_get_args();


File: /app/orditech.application/helpers/webges_helper.php
> Line 270: Removed function "eregi_replace" called
    eregi_replace('[ ]+', ' ', $chaine);

Checked 2238 files in 33.930 seconds
