File: /app/class/error.class.php
> Line 67: Class/trait/interface "Error" was added in the global namespace
    class error
    {
    }
