$arr = explode(',', $opts['t']);
