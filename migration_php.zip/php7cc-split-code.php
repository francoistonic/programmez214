$arr = split(',', $opts['t']);
