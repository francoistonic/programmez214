File: /app/orditech.application/third_party/Numbers_Words/Numbers/Words/Locale/bg.php
> Line 272: PHP 4 constructors are now deprecated
    function Numbers_Words_Locale_bg()
    {
    }
