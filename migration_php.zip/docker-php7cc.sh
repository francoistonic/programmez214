docker run -it -–rm -v path/to/app:/app ypereirareis/php7cc php7cc —extensions=php /app
