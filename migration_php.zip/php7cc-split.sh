File: /app/orditech.application/third_party/dompdf/dompdf.php
> Line 185: Removed function "split" called
    split(',', $opts['t']);
