File: /app/includes/functions.inc.php
> Line 1057: Removed function "ereg_replace" called
    ereg_replace('[^[:alnum:]\\?]', '', $VAT);
> Line 1058: Removed function "ereg" called
    ereg('(^U{1})([0-9]{1,7})([0-9]{1}$|\\?{1}$)', $FAN, $REGS);
> Line 1073: Removed function "ereg" called
    ereg('\\?{1}', $CTR);
> Line 1082: Removed function "ereg_replace" called
    ereg_replace('[^[:alnum:]\\?]', '', $VAT);
> Line 1083: Removed function "ereg" called
    ereg('(^[0-9]{1,8})([0-9]{2}$|\\?{1,2}$)', $FAN, $REGS);
