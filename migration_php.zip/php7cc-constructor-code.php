// La syntaxe de constructeur qui nous pose problème
function Numbers_Words_Locale_bg()
{
}
// remplacé par cette syntaxe de constructeur
function __construct()
{
}
