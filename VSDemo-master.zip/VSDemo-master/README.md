# VSDemo
This is a light IDE for compiling source code for my daughter. It uses Roslyn to compile C#.
I build using VS2015. The project is made with C++ and MFC. You can also use it as multi-file MDI editor.

To run the VSDemo application, you need to extract the Roslyn nupkg using 7zip tool and set the tools folder in VSDemo. Make a right-click on Project item and a dialog box let you enter the full path to CSC.exe

To add references on a project, make a right-click on References item. It will display a dialog box where you can choose a dll from .NET 4.6.2 references folder or you choose any module you want using Browse button.
