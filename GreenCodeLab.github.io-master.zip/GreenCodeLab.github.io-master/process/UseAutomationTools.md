---
validated: false
level: 2
---

## Utiliser des outils d'automatisation : TU, TF, IC...

*À RÉDIGER*
