---
validated: false
level: 2
---

## Libérer de la mémoire les variables qui ne sont plus nécessaires

*À RÉDIGER*
