---
validated: false
level: 2
---

## Utiliser des variables statiques pour prendre en compte le contexte

*À RÉDIGER*
