---
validated: true
level: 1
---

## Adapter le fonctionnement si l’utilisateur ne visualise pas la fenêtre

*À RÉDIGER*
