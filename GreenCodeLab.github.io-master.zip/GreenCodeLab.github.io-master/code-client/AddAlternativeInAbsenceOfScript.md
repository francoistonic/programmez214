---
validated: false
level: 2
---

## Proposer une alternative en l'abscence de script

*À RÉDIGER*
