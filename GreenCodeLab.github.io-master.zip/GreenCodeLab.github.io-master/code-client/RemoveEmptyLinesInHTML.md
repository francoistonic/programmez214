---
validated: false
level: 1
---

## Supprimer les lignes vides du HTML

*À RÉDIGER*
