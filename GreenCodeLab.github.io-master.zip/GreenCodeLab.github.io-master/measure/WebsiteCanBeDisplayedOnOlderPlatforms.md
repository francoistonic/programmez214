---
validated: false
level: 2
---

## Le site doit pouvoir s'afficher sur une plateforme ancienne

*À RÉDIGER*
