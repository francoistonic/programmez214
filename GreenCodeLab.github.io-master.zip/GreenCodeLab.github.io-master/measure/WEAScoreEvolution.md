---
validated: false
level: 2
---

## Le score WEA ne doit pas dépasser 20% de la valeur lors de l'audit pendant plus de 2 mois

*À RÉDIGER*
