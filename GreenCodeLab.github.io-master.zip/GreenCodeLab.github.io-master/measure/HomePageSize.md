---
validated: false
level: 2
---

## La taille de la page principale ne doit pas dépasser la taille moyenne des sites du panel WEA (50)

*À RÉDIGER*
