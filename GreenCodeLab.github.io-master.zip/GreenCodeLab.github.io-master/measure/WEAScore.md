---
validated: true
level: 1
---

## Le score WEA du site doit être supérieur ou égal à C

Notation :

- étiquette A = 2 points ;
- étiquette B = 1 point ;
- étiquette C = 0 point ;
- étiquette D, E, F, G, = critère éliminatoire pour la labellisation.
