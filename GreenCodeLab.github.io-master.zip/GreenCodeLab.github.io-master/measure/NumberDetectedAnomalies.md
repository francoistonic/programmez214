---
validated: false
level: 2
---

## Nombre d'anomalies ouvertes par rapport à la charge du projet

*À RÉDIGER*
