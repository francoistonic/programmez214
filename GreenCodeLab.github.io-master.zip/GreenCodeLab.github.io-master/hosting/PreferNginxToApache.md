---
validated: false
level: 2
---

## Préférer Nginx à Apache lorsque c’est possible

*À RÉDIGER*
