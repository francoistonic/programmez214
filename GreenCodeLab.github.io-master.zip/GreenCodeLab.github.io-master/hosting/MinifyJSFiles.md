---
validated: true
level: 2
---

## Minifier les fichiers JavaScript

Réduire la taille des fichiers JavaScript.

Les fichiers JavaScript écrits peuvent être optimisés en supprimant les commentaires et espaces inutiles à leur interprétation par le navigateur.

L'utilisation de moteurs de compression permet de minifier les JS utilisés (qui ne contiendront plus qu'une seule ligne).
