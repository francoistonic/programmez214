---
validated: false
level: 2
---

## Installer le minimum d'outil et de programme requis sur le serveur

Pour la vérification de cette règle, il est nécessaire d'avoir :

- soit un accès à la VM ;
- soit une liste des processus actifs (ps sous linux).

Pour des hébergements mutualisés, il est demandé une connexion à l'interface pour voir les services activés.
