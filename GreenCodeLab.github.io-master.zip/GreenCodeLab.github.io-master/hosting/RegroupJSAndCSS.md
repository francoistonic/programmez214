---
validated: true
level: 1
---

## Regrouper les JavaScript et les CSS

Réduire la taille des fichiers CSS et JavaScript envoyés au navigateur.

Les fichiers CSS contrôlent le style d’une page web et les fichiers JavaScript contrôlent le comportement d'une page web.
Lorsque plusieurs fichiers sont utilisés, ils peuvent être regroupés en un seul fichier afin d'éviter de multiples requêtes HTTP.
