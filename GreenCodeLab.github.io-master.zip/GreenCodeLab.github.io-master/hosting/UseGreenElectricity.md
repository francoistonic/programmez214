---
validated: false
level: 2
---

## Utiliser une électricité "verte"

*À RÉDIGER*
