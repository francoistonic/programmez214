---
validated: false
level: 2
---

## Redimensionner les images en dehors du CMS

*À RÉDIGER*
