---
validated: false
level: 2
---

## N'utiliser que des fichiers double opt-in

*À RÉDIGER*
