---
validated: false
level: 2
---

## Encoder les sons en dehors du CMS

*À RÉDIGER*
