---
validated: false
level: 2
---

## Dédoublonner systématiquement les fichiers avant envoi

*À RÉDIGER*
