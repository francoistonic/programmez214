---
validated: true
level: 1
---

## Adapter les vidéos aux périphériques de visualisation

Diminuer la taille des vidéos servies en fonction de la taille de l’écran de l’utilisateur.

Prévoir plusieurs formats et tailles de vidéos permet de fournir à l’utilisateur un média adapté à son périphérique, et diminuer ainsi la taille du fichier à charger pour l’utilisateur final.

Avec HTML5, utiliser plusieurs attributs "src" dans la balise vidéo, servies en fonction du navigateur et/ou de la taille de l'écran.
